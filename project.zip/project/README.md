# My Book Repository
#### Video Demo:  <URL HERE>
#### Description:
This web application allows the user to create a list of books that they have read, or books that they intend to read.
I decided to create this application as I am an avid reader and I often forget if I have read a book or not, or even if I have purchased a book that I intended to read but don't remember.
The application allows the user to enter the title, author , status(read/unread) and link a review that they have written(if they have).
I decided to use html, css, python, boostrap and javascript to create the web application.
The bulk of the CSS code was taken from boostrap and simply implemented.
I created a database using SQL to store the input.